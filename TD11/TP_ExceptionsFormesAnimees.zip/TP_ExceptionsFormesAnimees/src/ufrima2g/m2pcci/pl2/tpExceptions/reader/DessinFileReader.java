package ufrima2g.m2pcci.pl2.tpExceptions.reader;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import ufrim2ag.m2pcci.pl2.formesanimees.animation.IAnimateur;
import ufrim2ag.m2pcci.pl2.formesanimees.dessin.Dessin;
import ufrim2ag.m2pcci.pl2.formesanimees.dessin.IDessinable;
import ufrim2ag.m2pcci.pl2.formesanimees.formes.IForme;
import ufrim2ag.m2pcci.pl2.formesanimees.formes.FormeAnimée;
import ufrim2ag.m2pcci.pl2.formesanimees.formes.PolygoneRegulier;


/**
 * Cette classe permet de lire un fichier texte contenant la description des
 * différents objets à afficher et à animer dans la fenêtre de l'application.
 *
 * @author Philippe Genoud - UJF Grenoble - Lab LIG-Steamer
 */
public class DessinFileReader {

    /**
     *
     * @param fileName le nom (en fait le chemin) du fichier texte
     * @param dessin le dessin auquel les objets créés à partir des descriptions
     * contenues dans le fichier sont ajoutés
     *
     * @throws FileNotFoundException si fileName ne correspond pas un fichier
     * existant
     * @throws IOException en cas d'erreur de lecture (au niveau système)
     * @throws UnknownObjectException en cas de type d'objet non supporté
     * @throws UnknownFormeException en cas de type de forme non supporté
     * @throws NombreArgumentsIncorrect quand le nombre d'arguments d'une
     * description ne correspond pas au nombre d'arguments attendus.
     */
    public static void chargerDessinables(String fileName, Dessin dessin)
            throws FileNotFoundException, IOException, UnknownObjectException, UnknownFormeException,
            NombreArgumentsIncorrect {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            // try avec ressources, qui permet de fermer automatiquement le reader

            String ligne; // chaîne contenant la ligne courante.
            int noLigne = 0;    // numéro de la ligne en cours d'analyse.
            IForme forme; // la dernière forme créée
            IAnimateur animator = null; // le dernier animateur lu
            ligne = reader.readLine();
            while (ligne != null) {

                noLigne++;
                System.out.println(ligne);
                if (!"".equals(ligne) && !ligne.startsWith("#")) {

                    // ligne non vide et non commentaire
                    // recupération dans un tableau de chaînes des différents élements de la ligne
                    String[] tokens = ligne.toUpperCase().split(" ");

                    switch (tokens[0]) {
                        case "F":
                            forme = lireForme(tokens[1], Arrays.copyOfRange(tokens, 2, tokens.length));
                            System.out.println("--> forme créée");
                            if (animator != null) {
                                dessin.ajouterObjet(new FormeAnimée(forme, animator));
                                animator = null;
                            } else {
                                dessin.ajouterObjet(forme);
                            }
                            break;
                        case "A":
                            System.out.println("Animateur");
                            animator = lireAnimator(tokens);
                            break;
                        case "C":
                            System.out.println("Chenille");
                            dessin.ajouterObjet(lireChenille(tokens));
                            break;
                        default:
                            throw new UnknownObjectException(tokens[0]);
                    }

                } // fin du if (! ligne.equals(""))
                
                // on passe à la ligne suivante
                ligne = reader.readLine();
            }
        }
    }

    /**
     *
     * @param typeForme le type de la forme
     * @param paramsForme le tableau des paramètres de la forme
     *
     * @return la référence d'un objet forme correspondant à la description
     *
     * @throws UnknownFormeException si le type de forme n'est pas reconnu.
     *
     * @throws NombreArgumentsIncorrect si le nombre de paramètres de
     * description n'est pas le nombre attendu.
     */
    private static IForme lireForme(String typeForme, String[] paramsForme) throws
            UnknownFormeException, NombreArgumentsIncorrect {
        switch (typeForme) {
            case "POLYR":
                return lirePolyRegulier(paramsForme);
            default:
                throw new UnknownFormeException(typeForme);
        }
    }

    /**
     *
     * @param params les paramètres permettant de décrire un polygone régulier
     *
     * @return la référence d'un objet PolygoneRegulier correspondant à ces
     * paramètres
     *
     * @throws NombreArgumentsIncorrect si le nombre de paramètres de
     * description n'est pas le nombre attendu (ici 7).
     */
    private static PolygoneRegulier lirePolyRegulier(String[] params) throws NombreArgumentsIncorrect {
        if (params.length != 7) {
            throw new NombreArgumentsIncorrect("POLYR", params.length, 7);
        }
        int x = Integer.parseInt(params[0]);
        int y = Integer.parseInt(params[1]);
        int r = Integer.parseInt(params[2]);
        int n = Integer.parseInt(params[3]);
        Color c = new Color(Integer.parseInt(params[4]), Integer.parseInt(params[5]),
                    Integer.parseInt(params[6]));
        return new PolygoneRegulier( n, x, y, r, 1.0f, c, c);
    }

    private static IAnimateur lireAnimator(String[] tokens) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static IDessinable lireChenille(String[] tokens) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
