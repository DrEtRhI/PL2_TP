package im2ag.m2pcci.reservations;

/**
 *
 * @author Philippe GENOUD - Université Grenoble Alpes - Lab LIG-Steamer
 */
public class Materiel {
     // A COMPLETER
}
